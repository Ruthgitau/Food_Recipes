package com.example.food_recipes.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.food_recipes.R

class DetailRecipeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_recipe)
    }
}