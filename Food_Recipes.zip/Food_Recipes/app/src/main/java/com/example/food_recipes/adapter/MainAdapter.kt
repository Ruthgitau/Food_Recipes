package com.example.food_recipes.adapter

class MainAdapter {
}